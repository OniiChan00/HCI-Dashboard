import React from 'react'
import Homework from './Homework'
import Nav_Bar from './Nav_Bar'

export default function Home() {
  return (
    <div><Nav_Bar/>
    <Homework/>
    </div>
  )
}
